Original LEGO Model
-------------------
Set #    : 7452
Name     : Le Mans
Year     : 2007
Theme    : Racers
Part #   : 34
Polygun #: 23064

Site     : 3DBrickWorld.com
Email    : info@3dbrickworld.com
Category : Car

Formats
-------
.MAX     : Autodesk 3DS Max 2018
.3DS     : Autodesk 3D Studio
.C4D     : Maxon Cinema 4D Studio R18
.DAE     : Autodesk Collada
.FBX     : Autodesk FBX
.LXF     : LEGO Digital Designer 4.3
.PNG     : Image PNG